# MAC0499 - LaTeX CI-CD
Esse repositório contém o código fonte de um contêiner que automaticamente faz a build da dissertação do meu Trabalho de Conclusão de Curso. O código fonte está localizado no diretório ./src. O container lê o arquivo buildtarget para decidir qual comando do Make rodar. 

Para ver um repositório que usa essa pipeline, dê uma olhada no meu [Trabalho de Conclusão de Curso](https://github.com/LeRenner/mac0499-dissertation). Esse repositório automaticamente constrói as imagens de Docker usando o Github Actions. 