make tese

sftp linux:/home/bmac/renner/www/MAC0499 <<< $'put ./tese.pdf'
