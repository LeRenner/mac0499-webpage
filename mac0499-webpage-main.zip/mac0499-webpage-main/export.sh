sftp linux:/home/bmac/renner/www/MAC0499 <<< $'put -r *'
