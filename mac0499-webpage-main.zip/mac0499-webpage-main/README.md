# MAC0499 - Webpage
Este repositório contém o código fonte da página principal do meu Trabalho de Conclusão de Curso. Ele contém uma pipeline de CI-CD que automaticamente publica o site na minha página da rede linux a cada commit.
