# MAC0499 - Prototype

This repository contains the source code for the implementation of a descentralized messaging application. It is a part of my Capstone Project for my Computer Science undergraduate degree. 

You can read more information about this project on [its homepage](https://linux.ime.usp.br/~renner/MAC0499/)
